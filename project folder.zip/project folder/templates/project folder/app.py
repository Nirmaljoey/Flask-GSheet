from flask import Flask, request, redirect, url_for, render_template, flash
import gspread
from oauth2client.service_account import ServiceAccountCredentials

# ✅ Initialize Flask app
app = Flask(__name__)
app.secret_key = 'your_secret_key'

# ✅ Google Sheets API Setup
try:
    credentials_path = r"C:\Users\amalj\OneDrive\Desktop\project folder\credentials.json"
    SCOPE = ['https://www.googleapis.com/auth/spreadsheets']  # Updated scope
    CREDS = ServiceAccountCredentials.from_json_keyfile_name(credentials_path, SCOPE)
    CLIENT = gspread.authorize(CREDS)
    SHEET = CLIENT.open_by_key('107pXCVc2Ttg2swv2z6ziBhsUZh26SoCXkE9bGFofTmQ').sheet1
    print("✅ Google Sheets connected successfully!")
except Exception as e:
    print(f"❌ Google Sheets Connection Error: {e}")

# ✅ Route for Transport Form Submission
@app.route('/', methods=['GET', 'POST'])
def transport_form():
    if request.method == 'POST':
        try:
            # Collect data from the form
            date = request.form.get('date')
            driver_name = request.form.get('driver_name')
            vehicle_plate = request.form.get('vehicle_plate')
            start_time = request.form.get('start_time')
            arrival_time = request.form.get('arrival_time')
            location = request.form.get('location')
            odometer_start = request.form.get('odometer_start')
            odometer_end = request.form.get('odometer_end')
            Notes = request.form.get('Notes')
            
            # Validate essential fields
            if not all([date, driver_name, vehicle_plate, start_time, arrival_time, location, odometer_start, odometer_end, Notes]):
                flash('❌ All fields are required.', 'danger')
                return redirect(url_for('transport_form'))
            
            # Append data to Google Sheets
            SHEET.append_row([
                date, driver_name, vehicle_plate, start_time, arrival_time,
                location, odometer_start, odometer_end, Notes
            ])
            flash('✅ Data added to Google Sheets successfully!', 'success')
        
        except Exception as e:
            flash(f'❌ Error adding data: {e}', 'danger')
        
        return redirect(url_for('transport_form'))
    
    return render_template('form.html')

# ✅ Run App
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
