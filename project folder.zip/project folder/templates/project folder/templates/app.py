from flask import Flask, render_template, redirect, url_for, flash
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, DateTimeField
from wtforms.validators import DataRequired, Regexp
from datetime import datetime
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'

# ✅ Google Sheets setup
try:
    current_dir = os.path.dirname(os.path.abspath(__file__))
    credentials_path = os.path.join(current_dir, 'credentials.json')

    SCOPE = ['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive']
    creds = ServiceAccountCredentials.from_json_keyfile_name(credentials_path, scopes=SCOPE)
    client = gspread.authorize(creds)
    sheet = client.open_by_key('107pXCVc2Ttg2swv2z6ziBhsUZh26SoCXkE9bGFofTmQ').sheet1
    print("✅ Google Sheets connected successfully!")
except Exception as e:
    print(f"❌ Google Sheets Connection Error: {e}")

# ✅ Form Class
class TransportForm(FlaskForm):
    date = StringField(
        'Date (mm/dd/yyyy)',
        validators=[
            DataRequired(message="Date is required."),
            Regexp(
                r"^(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/(20[0-5][0-9])$",
                message="Date must be in mm/dd/yyyy format and valid range."
            ),
        ],
    )
    driver_name = StringField('Driver Name', validators=[DataRequired()])
    vehicle_plate = StringField('Vehicle Plate #', validators=[DataRequired()])
    start_time = DateTimeField('Start Time (HH:MM AM/PM)', format='%I:%M %p', validators=[DataRequired()])
    arrival_time = DateTimeField('Arrival Time (HH:MM AM/PM)', format='%I:%M %p', validators=[DataRequired()])
    location = StringField('Location (From > To)', validators=[DataRequired()])
    odometer_start = StringField(
        'Odometer Reading Start',
        validators=[DataRequired(), Regexp(r"^\d+$", message="Must be a number.")]
    )
    odometer_end = StringField(
        'Odometer Reading End',
        validators=[DataRequired(), Regexp(r"^\d+$", message="Must be a number.")]
    )
    reason = StringField('Reason', validators=[DataRequired()])
    next_service = StringField('Vehicle Next Service', validators=[DataRequired()])
    submit = SubmitField('Submit')
    clear = SubmitField('Clear Form')

# ✅ Route for Transport Form
@app.route('/', methods=['GET', 'POST'])
def transport_form():
    form = TransportForm()
    if form.validate_on_submit():
        if form.submit.data:  # Submit button clicked
            try:
                # Extract form data
                date = form.date.data
                driver_name = form.driver_name.data
                vehicle_plate = form.vehicle_plate.data
                start_time = form.start_time.data.strftime('%I:%M %p')
                arrival_time = form.arrival_time.data.strftime('%I:%M %p')
                location = form.location.data
                odometer_start = form.odometer_start.data
                odometer_end = form.odometer_end.data
                reason = form.reason.data
                next_service = form.next_service.data

                # ✅ Append data to Google Sheets
                sheet.append_row([
                    date, driver_name, vehicle_plate, start_time, arrival_time,
                    location, odometer_start, odometer_end, reason, next_service
                ])
                flash('✅ Form submitted successfully! Data has been stored in Google Sheets.', 'success')
                print("✅ Data successfully stored in Google Sheets.")
                return redirect(url_for('transport_form'))
            except gspread.exceptions.APIError as e:
                flash(f'❌ Google Sheets API Error: {e}', 'danger')
                print("Google Sheets API Error:", e)
            except Exception as e:
                flash(f'❌ An error occurred: {e}', 'danger')
                print("General Error:", e)
        
        if form.clear.data:  # Clear button clicked
            return redirect(url_for('transport_form'))
    else:
        if form.errors:
            print("❌ Form Errors:", form.errors)
    
    return render_template('form.html', form=form)

# ✅ Debugging Route for Google Sheets
@app.route('/test-google-sheets')
def test_google_sheets():
    try:
        sheet.append_row([
            "Test Entry", "Test Driver", "Plate123", "12:00 PM", "1:00 PM",
            "Test > Test", "100", "200", "Test Reason", "Test Service"
        ])
        return "✅ Google Sheets test row added successfully!"
    except gspread.exceptions.APIError as e:
        return f"❌ Google Sheets API Error: {e}"
    except Exception as e:
        return f"❌ Error: {e}"

# ✅ Run App
if __name__ == '__main__':
    app.run(debug=True)
